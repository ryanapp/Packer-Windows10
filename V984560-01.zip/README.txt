Oracle VirtIO 1.1.5 Drivers for Microsoft Windows
=================================================

The VirtIO 1.1.5 release provides:

- An updated installer to configure a guest VM for migration from another VM
  technology to the Oracle Cloud Infrastructure (OCI) without the need to select
  a Custom installation.

- Updated VirtIO SCSI and Block storage drivers to 1.1.5 with support for
  dumping crash files.

- The signing of the drivers to Microsoft Windows 2019.

The installer enables the use of the VirtIO drivers at boot time so
that the migrated guest can boot in OCI.

Note: If installing these drivers on Microsoft Windows 2008 SP2 and 2008 R2, you
      will need to first install the following update from Microsoft:

      - 2019-08 Security Update for Windows Server 2008 for x64-based Systems (KB4474419)

      Failure to do this may result in errors during installation due to the
      inability to validate signatures of the drivers. Please follow normal
      Windows installation procedure for this Microsoft update.

Note: The remaining installed VirtIO drivers remain unchanged from
      the 1.1.2 release, only the VirtIO SCSI and Block drivers have
      updated version numbers.


For more information on installing the VirtIO drivers, please refer to
the documentation at:

  https://docs.oracle.com/cd/E52668_01/E54669/html/ol7-kvm-virtio.html
